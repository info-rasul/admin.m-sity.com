-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Фев 24 2017 г., 16:27
-- Версия сервера: 5.6.34
-- Версия PHP: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `m-sity`
--

-- --------------------------------------------------------

--
-- Структура таблицы `flatRent`
--

CREATE TABLE `flatRent` (
  `id_object` int(11) NOT NULL,
  `FlatRoomsCount` enum('1','2','3','4','5','6','7','8','9') NOT NULL,
  `IsApartments` tinyint(1) NOT NULL,
  `IsPenthouse` tinyint(1) NOT NULL,
  `TotalArea` double NOT NULL,
  `FloorNumber` int(64) NOT NULL,
  `AllRoomsArea` text NOT NULL,
  `LivingArea` double NOT NULL,
  `KitchenArea` double NOT NULL,
  `LoggiasCount` enum('0','1','2','3','4') NOT NULL,
  `BalconiesCount` enum('0','1','2','3','4') NOT NULL,
  `WindowsViewType` enum('street','yard','yardAndStreet') NOT NULL,
  `SeparateWcsCount` enum('0','1','2','3','4') NOT NULL,
  `CombinedWcsCount` enum('0','1','2','3','4') NOT NULL,
  `RepairType` enum('cosmetic','design','euro','no') NOT NULL,
  `HasInternet` tinyint(1) NOT NULL,
  `HasFurniture` tinyint(1) NOT NULL,
  `HasPhone` tinyint(1) NOT NULL,
  `HasKitchenFurniture` tinyint(1) NOT NULL,
  `HasTv` tinyint(1) NOT NULL,
  `HasWasher` tinyint(1) NOT NULL,
  `HasConditioner` tinyint(1) NOT NULL,
  `HasBathtub` tinyint(1) NOT NULL,
  `HasShower` tinyint(1) NOT NULL,
  `HasDishwasher` tinyint(1) NOT NULL,
  `PetsAllowed` tinyint(1) NOT NULL,
  `HasFridge` tinyint(1) NOT NULL,
  `ChildrenAllowed` tinyint(1) NOT NULL,
  `Name` text NOT NULL,
  `FloorsCount` int(64) NOT NULL,
  `BuildYear` int(64) NOT NULL,
  `MaterialType` enum('block','boards','brick','monolith','monolithBrick','old','panel','stalin','wood') NOT NULL,
  `Series` text NOT NULL,
  `CeilingHeight` double NOT NULL,
  `PassengerLiftsCount` enum('0','1','2','3','4') NOT NULL,
  `CargoLiftsCount` enum('0','1','2','3','4') NOT NULL,
  `HasGarbageChute` tinyint(1) NOT NULL,
  `Parking` enum('ground','multilevel','open','roof','underground') NOT NULL,
  `Price` double NOT NULL,
  `IncludedInPrice` tinyint(1) NOT NULL,
  `SumPrice` double NOT NULL,
  `Currency` enum('rur','eur','usd') NOT NULL,
  `BargainAllowed` tinyint(1) NOT NULL,
  `BargainPrice` double NOT NULL,
  `BargainConditions` text NOT NULL,
  `LeaseTermType` enum('fewMonths','longTerm') NOT NULL,
  `PrepayMonths` enum('1','2','3','4','5','6','7','8','9','10','11','12') NOT NULL,
  `Deposit` int(64) NOT NULL,
  `ClientFee` int(64) NOT NULL,
  `AgentFee` int(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `flatRent`
--

INSERT INTO `flatRent` (`id_object`, `FlatRoomsCount`, `IsApartments`, `IsPenthouse`, `TotalArea`, `FloorNumber`, `AllRoomsArea`, `LivingArea`, `KitchenArea`, `LoggiasCount`, `BalconiesCount`, `WindowsViewType`, `SeparateWcsCount`, `CombinedWcsCount`, `RepairType`, `HasInternet`, `HasFurniture`, `HasPhone`, `HasKitchenFurniture`, `HasTv`, `HasWasher`, `HasConditioner`, `HasBathtub`, `HasShower`, `HasDishwasher`, `PetsAllowed`, `HasFridge`, `ChildrenAllowed`, `Name`, `FloorsCount`, `BuildYear`, `MaterialType`, `Series`, `CeilingHeight`, `PassengerLiftsCount`, `CargoLiftsCount`, `HasGarbageChute`, `Parking`, `Price`, `IncludedInPrice`, `SumPrice`, `Currency`, `BargainAllowed`, `BargainPrice`, `BargainConditions`, `LeaseTermType`, `PrepayMonths`, `Deposit`, `ClientFee`, `AgentFee`) VALUES
(102, '1', 1, 0, 52, 2, '40', 20, 10, '1', '0', 'yardAndStreet', '2', '1', 'design', 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 'Алые паруса', 5, 1999, 'stalin', '4', 3, '1', '2', 0, 'multilevel', 100500, 1, 0, 'rur', 1, 100000, 'trfhy hfgh gfh fghg ', 'fewMonths', '1', 9, 0, 0),
(103, '1', 1, 0, 52, 2, '40', 20, 10, '1', '0', 'yardAndStreet', '2', '1', 'design', 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 'Алые паруса', 5, 1999, 'stalin', '4', 3, '1', '2', 0, 'multilevel', 100500, 1, 0, 'rur', 1, 100000, 'trfhy hfgh gfh fghg ', 'fewMonths', '1', 9, 0, 0),
(104, '1', 1, 0, 52, 2, '40', 20, 10, '1', '0', 'yardAndStreet', '2', '1', 'design', 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 'Алые паруса', 5, 1999, 'stalin', '4', 3, '1', '2', 0, 'multilevel', 100500, 1, 0, 'rur', 1, 100000, 'trfhy hfgh gfh fghg ', 'fewMonths', '1', 9, 0, 0),
(105, '1', 1, 0, 52, 2, '40', 20, 10, '1', '0', 'yardAndStreet', '2', '1', 'design', 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 'Алые паруса', 5, 1999, 'stalin', '4', 3, '1', '2', 0, 'multilevel', 100500, 1, 0, 'rur', 1, 100000, 'trfhy hfgh gfh fghg ', 'fewMonths', '1', 9, 0, 0),
(106, '1', 1, 0, 52, 2, '40', 20, 10, '1', '0', 'yardAndStreet', '2', '1', 'design', 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 'Алые паруса', 5, 1999, 'stalin', '4', 3, '1', '2', 0, 'multilevel', 100500, 1, 0, 'rur', 1, 100000, 'trfhy hfgh gfh fghg ', 'fewMonths', '1', 9, 0, 0),
(107, '1', 1, 0, 52, 2, '40', 20, 10, '1', '0', 'yardAndStreet', '2', '1', 'design', 0, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 'Алые паруса', 5, 1999, 'stalin', '4', 3, '1', '2', 0, 'multilevel', 100500, 1, 0, 'rur', 1, 100000, 'trfhy hfgh gfh fghg ', 'fewMonths', '1', 9, 0, 0),
(108, '2', 1, 1, 52, 2, '40', 20, 10, '1', '2', 'yardAndStreet', '1', '2', 'cosmetic', 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 'Алые паруса', 5, 1999, 'monolithBrick', '4', 3, '1', '1', 0, 'multilevel', 100500, 1, 0, 'eur', 1, 100000, 'ывапа вапвапвапвап', 'longTerm', '6', 9, 4, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `Highway`
--

CREATE TABLE `Highway` (
  `id_object` int(11) NOT NULL,
  `Distance` double NOT NULL,
  `Id` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `LayoutPhoto`
--

CREATE TABLE `LayoutPhoto` (
  `id_object` int(11) NOT NULL,
  `FullUrl` text NOT NULL,
  `IsDefault` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `object`
--

CREATE TABLE `object` (
  `ExternalId` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('published','draft') NOT NULL DEFAULT 'draft',
  `Description` longtext NOT NULL,
  `Address` text NOT NULL,
  `Lat` double NOT NULL,
  `Lng` double NOT NULL,
  `CadastralNumber` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `object`
--

INSERT INTO `object` (`ExternalId`, `user_id`, `status`, `Description`, `Address`, `Lat`, `Lng`, `CadastralNumber`) VALUES
(88, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(89, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(90, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(91, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(92, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(93, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(94, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(95, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(96, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(97, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(98, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(99, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(100, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(101, 0, 'draft', 'Описание объеккта', 'Россия, Москва, Гагаринский переулок, 19/3', 55.744311978026, 37.594627179687, '47:14:1203001:814'),
(102, 0, 'draft', 'fdhfg fgt df gdfgd gfd gdfg', 'Россия, Москва, улица Доватора, 7/8', 55.723971876338, 37.569221295898, '47:14:1203001:814'),
(103, 0, 'draft', 'fdhfg fgt df gdfgd gfd gdfg', 'Россия, Москва, улица Доватора, 7/8', 55.723971876338, 37.569221295898, '47:14:1203001:814'),
(104, 0, 'draft', 'fdhfg fgt df gdfgd gfd gdfg', 'Россия, Москва, улица Доватора, 7/8', 55.723971876338, 37.569221295898, '47:14:1203001:814'),
(105, 0, 'draft', 'fdhfg fgt df gdfgd gfd gdfg', 'Россия, Москва, улица Доватора, 7/8', 55.723971876338, 37.569221295898, '47:14:1203001:814'),
(106, 0, 'draft', 'fdhfg fgt df gdfgd gfd gdfg', 'Россия, Москва, улица Доватора, 7/8', 55.723971876338, 37.569221295898, '47:14:1203001:814'),
(107, 2, 'draft', 'fdhfg fgt df gdfgd gfd gdfg', 'Россия, Москва, улица Доватора, 7/8', 55.723971876338, 37.569221295898, '47:14:1203001:814'),
(108, 2, 'draft', 'цукпаыв павыпвапвап', 'Россия, Москва, улица Климашкина', 55.767448002606, 37.575057782715, '47:14:1203001:814');

-- --------------------------------------------------------

--
-- Структура таблицы `Phones`
--

CREATE TABLE `Phones` (
  `id_object` int(11) NOT NULL,
  `CountryCode` varchar(5) NOT NULL,
  `Number` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Phones`
--

INSERT INTO `Phones` (`id_object`, `CountryCode`, `Number`) VALUES
(103, '+7', '9885556633'),
(103, '+7', '98885556633'),
(104, '+7', '9885556633'),
(104, '+7', '98885556633'),
(105, '+7', '9885556633'),
(105, '+7', '98885556633'),
(106, '+7', '9885556633'),
(106, '+7', '98885556633'),
(107, '+7', '9885556633'),
(107, '+7', '98885556633'),
(108, '+7', '89484'),
(108, '+7', '598984198');

-- --------------------------------------------------------

--
-- Структура таблицы `Photos`
--

CREATE TABLE `Photos` (
  `id_object` int(11) NOT NULL,
  `FullUrl` text NOT NULL,
  `IsDefault` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Photos`
--

INSERT INTO `Photos` (`id_object`, `FullUrl`, `IsDefault`) VALUES
(103, './files/2017-02/1.jpg', 0),
(103, './files/2017-02/2.jpg', 0),
(107, './files/2017-02/1.jpg', 0),
(107, './files/2017-02/2.jpg', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gravatar_id` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8_unicode_ci,
  `timezone` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `profile`
--

INSERT INTO `profile` (`user_id`, `name`, `public_email`, `gravatar_email`, `gravatar_id`, `location`, `website`, `bio`, `timezone`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `PublishTerms`
--

CREATE TABLE `PublishTerms` (
  `id_object` int(11) NOT NULL,
  `ServicesEnum` enum('free','highlight','paid','premium','top3') NOT NULL,
  `ExcludedServicesEnum` enum('highlight','premium','top3') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `social_account`
--

CREATE TABLE `social_account` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `client_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `code` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `token`
--

CREATE TABLE `token` (
  `user_id` int(11) NOT NULL,
  `code` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL,
  `type` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `token`
--

INSERT INTO `token` (`user_id`, `code`, `created_at`, `type`) VALUES
(1, 'K5_vMvs-zmthNGLaPMy2gebAJjtL8cUi', 1485210608, 0),
(2, 'L_5sWTeEc6kZ6ABQVfYqa0LrTbjGZ7CB', 1485378119, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `Underground`
--

CREATE TABLE `Underground` (
  `id_object` int(11) NOT NULL,
  `TransportType` enum('transport','walk') NOT NULL,
  `Time` int(32) NOT NULL,
  `Id` int(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `Underground`
--

INSERT INTO `Underground` (`id_object`, `TransportType`, `Time`, `Id`) VALUES
(102, 'walk', 5, 118),
(103, 'walk', 5, 118),
(104, 'walk', 5, 118),
(105, 'walk', 5, 118),
(106, 'walk', 5, 118),
(107, 'walk', 5, 118),
(108, 'walk', 12, 159),
(108, 'transport', 4, 2);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `confirmed_at` int(11) DEFAULT NULL,
  `unconfirmed_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `blocked_at` int(11) DEFAULT NULL,
  `registration_ip` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `last_login_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `auth_key`, `confirmed_at`, `unconfirmed_email`, `blocked_at`, `registration_ip`, `created_at`, `updated_at`, `flags`, `last_login_at`) VALUES
(1, 'admin', 'aliev-rsl@mail.ru', '25d55ad283aa400af464c76d713c07ad', 'O032ORI6tksPCejF_QroBbNaKFXSrFEc', 1485211361, NULL, NULL, '127.0.0.1', 1485210608, 1485210608, 0, 1486758227),
(2, 'admin2', 'aliev-rsl@mail.ru2', '$2y$10$COgQ80J4jBDRg9yrYgQXFeNtIPZqUnnTLcDkcGdyH8ateO8Z05zqC', 'UefJE7nEZ0Gcp63_qagKqC372vQB42B-', 1485211363, NULL, NULL, '127.0.0.1', 1485378119, 1485378119, 0, 1486932633);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `flatRent`
--
ALTER TABLE `flatRent`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `Highway`
--
ALTER TABLE `Highway`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `LayoutPhoto`
--
ALTER TABLE `LayoutPhoto`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `object`
--
ALTER TABLE `object`
  ADD PRIMARY KEY (`ExternalId`);

--
-- Индексы таблицы `Phones`
--
ALTER TABLE `Phones`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `Photos`
--
ALTER TABLE `Photos`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Индексы таблицы `PublishTerms`
--
ALTER TABLE `PublishTerms`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `social_account`
--
ALTER TABLE `social_account`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_unique` (`provider`,`client_id`),
  ADD UNIQUE KEY `account_unique_code` (`code`),
  ADD KEY `fk_user_account` (`user_id`);

--
-- Индексы таблицы `token`
--
ALTER TABLE `token`
  ADD UNIQUE KEY `token_unique` (`user_id`,`code`,`type`);

--
-- Индексы таблицы `Underground`
--
ALTER TABLE `Underground`
  ADD KEY `id_object` (`id_object`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_unique_username` (`username`),
  ADD UNIQUE KEY `user_unique_email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `object`
--
ALTER TABLE `object`
  MODIFY `ExternalId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;
--
-- AUTO_INCREMENT для таблицы `social_account`
--
ALTER TABLE `social_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `flatRent`
--
ALTER TABLE `flatRent`
  ADD CONSTRAINT `flatrent_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

--
-- Ограничения внешнего ключа таблицы `Highway`
--
ALTER TABLE `Highway`
  ADD CONSTRAINT `highway_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

--
-- Ограничения внешнего ключа таблицы `LayoutPhoto`
--
ALTER TABLE `LayoutPhoto`
  ADD CONSTRAINT `layoutphoto_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

--
-- Ограничения внешнего ключа таблицы `Phones`
--
ALTER TABLE `Phones`
  ADD CONSTRAINT `phones_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

--
-- Ограничения внешнего ключа таблицы `Photos`
--
ALTER TABLE `Photos`
  ADD CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

--
-- Ограничения внешнего ключа таблицы `PublishTerms`
--
ALTER TABLE `PublishTerms`
  ADD CONSTRAINT `publishterms_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

--
-- Ограничения внешнего ключа таблицы `Underground`
--
ALTER TABLE `Underground`
  ADD CONSTRAINT `underground_ibfk_1` FOREIGN KEY (`id_object`) REFERENCES `object` (`ExternalId`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
